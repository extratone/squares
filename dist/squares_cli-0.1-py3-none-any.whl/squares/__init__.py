# __init__.py
from .squares import main
